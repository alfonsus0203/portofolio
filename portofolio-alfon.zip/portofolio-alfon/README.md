# portfolio-alfon
### You are free to use any of the code in this project, but must change any images and personal details within.
## LIVE DEMO
### https://github.com/alfonsus0203/Alfonsus/upload/main/portofolio-alfon
### Please star this repo and follow me here on Github so that other can find this repository.

# Technologies Used

### HTML
63.7%
 
### CSS
31.1%
 
### JavaScript
5.2%
